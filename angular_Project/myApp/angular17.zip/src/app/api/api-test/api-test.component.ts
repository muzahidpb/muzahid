import { Component } from '@angular/core';
import { ServiceService } from 'src/app/service.service';

@Component({
  selector: 'app-api-test',
  templateUrl: './api-test.component.html',
  styleUrls: ['./api-test.component.css']
})
export class ApiTestComponent {

  data: any = ""
  page: number = 1
  // mydata :any = this.data.data
  constructor(private user: ServiceService) {
    this.getuser()
    

  }
  getuser() {
    this.user.getdata(this.page).subscribe((res) => {
      this.data = res
      // console.log(res);
    })
  }
  prev() {
    //  this.data = this.data.data.list.slice(2,6)
    // console.log(this.data.data.list);
    this.page -= 1
    this.getuser()

  }
  next() {
    // console.log("next is called");
    this.page += 1
    this.getuser()
  }

 async deletuser(e :any){
    console.log(e.target.value);
   await this.user.deletdata(e.target.value).subscribe((res :any)=>{
      console.log(res);
      if(res.success){
    this.getuser()

      }
    })

  }


  // showdata (){
  //   // for (let i =0; i<9; i++){
  //   //    this.mydata = [this.data.data.list[i]]
  //   // }
  //   this.mydata = this.data.list[0].job_id
  //   console.log(this.mydata);


  // }


  lang: string = ''

  handleChange(e: any) {
    let data = e.target.value;
    this.lang = data

  }

  stateData: string[] = ["gujarat", "rajastan", "delhi", "up", "bihar", "mp"]


}

