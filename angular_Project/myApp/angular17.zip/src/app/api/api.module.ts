import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiTestComponent } from './api-test/api-test.component';
import { ApiPostComponent } from './api-post/api-post.component';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    ApiTestComponent,
    ApiPostComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule
  ],
  exports : [
      ApiTestComponent,
      ApiPostComponent
  ]
})
export class ApiModule { }
