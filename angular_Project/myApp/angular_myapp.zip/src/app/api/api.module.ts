import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiTestComponent } from './api-test/api-test.component';



@NgModule({
  declarations: [
    ApiTestComponent
  ],
  imports: [
    CommonModule
  ],
  exports : [
      ApiTestComponent
  ]
})
export class ApiModule { }
